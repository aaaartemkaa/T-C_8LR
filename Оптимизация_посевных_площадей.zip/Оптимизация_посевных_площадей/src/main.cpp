#include "data.h"
#include "forecast.h"
#include "model.h"
#include "report.h"
#include "simplex.h"
#define NOMINMAX
#include <windows.h>
#include <knownfolders.h>
#include <objbase.h>
#include <shellapi.h>
#include <shlobj.h>
#include <filesystem>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

    constexpr int ID_OPEN_DIR = 101;
    constexpr int ID_OPEN_PLAN = 102;
    constexpr int ID_CLOSE = 103;
    constexpr int HEADER_PX = 92;
    struct Outcome {
        bool ok = false;
        std::wstring text;
        std::filesystem::path directory;
    };
    HWND g_edit = nullptr;
    HWND g_open_dir = nullptr;
    HWND g_open_plan = nullptr;
    HWND g_close = nullptr;
    HFONT g_title_font = nullptr;
    HFONT g_sub_font = nullptr;
    HFONT g_text_font = nullptr;
    HFONT g_button_font = nullptr;
    Outcome g_outcome;

    std::wstring widen(const std::string& utf8) {
        if (utf8.empty()) {
            return {};
        }
        const int size = MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), nullptr, 0);
        std::wstring wide(static_cast<size_t>(size), L'\0');
        MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), wide.data(), size);
        return wide;
    }

    int dpi_of(HWND hwnd) {
        const UINT dpi = GetDpiForWindow(hwnd);
        return dpi == 0 ? 96 : static_cast<int>(dpi);
    }

    int scale_px(HWND hwnd, int px_at_96) {
        return MulDiv(px_at_96, dpi_of(hwnd), 96);
    }

    std::filesystem::path executable_directory() {
        wchar_t buffer[MAX_PATH];
        const DWORD length = GetModuleFileNameW(nullptr, buffer, MAX_PATH);
        if (length == 0 || length >= MAX_PATH) {
            return {};
        }
        return std::filesystem::path(buffer).parent_path();
    }
    std::filesystem::path results_directory() {
        std::error_code ec;
        const std::filesystem::path cwd = std::filesystem::current_path();
        if (std::filesystem::exists(cwd / "PenzaCropOpt.sln", ec)) {
            return cwd / "results";
        }
        PWSTR documents = nullptr;
        if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Documents, 0, nullptr, &documents))) {
            const std::filesystem::path path = std::filesystem::path(documents) / L"Оптимизация посевных площадей";
            CoTaskMemFree(documents);
            return path;
        }
        return executable_directory() / "results";
    }

    // band_field: -1 низ 80% интервала, 0 медиана, +1 верх. Три сценария урожайности собираются одним проходом по таблице 10
    void fill_bootstrap(const InputData& data, int band_field, double yields[N_YEARS][N_CROPS]) {
        for (int slot = 0; slot < N_YEARS; ++slot) {
            for (int crop = 0; crop < N_CROPS; ++crop) {
                const Band& band = data.bootstrap[crop][slot];
                if (band_field < 0) {
                    yields[slot][crop] = band.low;
                }
                else if (band_field > 0) {
                    yields[slot][crop] = band.high;
                }
                else {
                    yields[slot][crop] = band.median;
                }
            }
        }
    }

    std::wstring decimal(double value, int precision) {
        std::ostringstream out;
        out.setf(std::ios::fixed);
        out.precision(precision);
        out << value;
        std::string text = out.str();
        for (char& symbol : text) {
            if (symbol == '.') {
                symbol = ',';
            }
        }
        return widen(text);
    }

    std::wstring right(const std::wstring& text, int width) {
        if (static_cast<int>(text.size()) >= width) {
            return text;
        }
        return std::wstring(static_cast<size_t>(width - text.size()), L' ') + text;
    }

    std::wstring grouped(double value) {
        long long number = std::llround(value);
        const bool negative = number < 0;
        if (negative) {
            number = -number;
        }
        const std::wstring digits = std::to_wstring(number);
        std::wstring text;
        int count = 0;
        for (int i = static_cast<int>(digits.size()) - 1; i >= 0; --i) {
            if (count > 0 && count % 3 == 0) {
                text.insert(text.begin(), L' ');
            }
            text.insert(text.begin(), digits[static_cast<size_t>(i)]);
            ++count;
        }
        if (negative) {
            text.insert(text.begin(), L'-');
        }
        return text;
    }

    double plan_margin(const Trajectory& trajectory, int slot) {
        const SolvedYear& year = trajectory.years[slot];
        double sum = 0;
        for (int i = 0; i < N_CROPS; ++i) {
            sum += money_of(trajectory.crops[static_cast<size_t>(i)], trajectory.params,
                year.yield[i], year.area[i]).margin_mln;
        }
        return sum;
    }

    double fact_margin(const Trajectory& trajectory, int slot) {
        double area[N_CROPS];
        for (int i = 0; i < N_CROPS; ++i) {
            area[i] = trajectory.crops[static_cast<size_t>(i)].area_2025;
        }
        return total_margin(trajectory.crops, trajectory.params, trajectory.years[slot].yield, area);
    }

    const Trajectory* find_key(const std::vector<Trajectory>& trajectories, const char* key) {
        for (const Trajectory& trajectory : trajectories) {
            if (trajectory.key == key) {
                return &trajectory;
            }
        }
        return nullptr;
    }

    std::wstring build_summary(const std::vector<Trajectory>& trajectories,
        const std::vector<MarginalEffect>& marginals, const std::filesystem::path& directory) {
        std::wstring text = L"Расчёт выполнен.\r\n\r\n";
        const Trajectory* base = find_key(trajectories, "base");
        const wchar_t* labels[N_CROPS] = {
            L"Зерно", L"Свёкла", L"Подсолнечник", L"Картофель", L"Овощи"
        };
        if (base != nullptr && base->ok) {
            text += L"Базовый сценарий. Площади, тыс. га\r\n";
            text += L"                2026     2027     2028\r\n";
            for (int i = 0; i < N_CROPS; ++i) {
                text += right(labels[i], 14);
                for (int slot = 0; slot < N_YEARS; ++slot) {
                    text += L"  " + right(decimal(base->years[slot].area[i], 1), 6);
                }
                text += L"\r\n";
            }
            text += L"\r\nМаржа, млн руб.\r\n";
            text += L"        план    площади 2025     выигрыш\r\n";
            double gain_sum = 0;
            for (int slot = 0; slot < N_YEARS; ++slot) {
                const double plan = plan_margin(*base, slot);
                const double fact = fact_margin(*base, slot);
                const double gain = plan - fact;
                gain_sum += gain;
                text += std::to_wstring(PLAN_YEARS[slot]);
                text += L"  " + right(grouped(plan), 8);
                text += L"  " + right(grouped(fact), 12);
                text += L"  " + right(grouped(gain), 10);
                text += L"\r\n";
            }
            text += L"3 года" + right(grouped(gain_sum), 34) + L"\r\n";
        }

        text += L"\r\nВыигрыш остальных сценариев за 3 года, млн руб.\r\n";
        for (const Trajectory& trajectory : trajectories) {
            if (trajectory.key == "base") {
                continue;
            }
            text += trajectory.title.empty() ? widen(trajectory.key) : widen(trajectory.title);
            if (!trajectory.ok) {
                text += L": не посчитан\r\n";
                continue;
            }
            double gain = 0;
            for (int slot = 0; slot < N_YEARS; ++slot) {
                if (trajectory.years[slot].ok) {
                    gain += plan_margin(trajectory, slot) - fact_margin(trajectory, slot);
                }
            }
            text += L"  " + grouped(gain) + L"\r\n";
        }

        if (!marginals.empty()) {
            text += L"\r\nПрирост маржи 2028 при одном ослабленном ограничении, млн руб.\r\n";
            for (const MarginalEffect& effect : marginals) {
                text += widen(effect.title) + L"  ";
                text += effect.computed ? decimal(effect.extra_margin_mln, 1) : L"—";
                text += L"\r\n";
            }
        }

        text += L"\r\nФайлы\r\n";
        text += (directory / L"plan.csv").wstring() + L"\r\n";
        text += (directory / L"trend.csv").wstring() + L"\r\n";
        text += (directory / L"effects.csv").wstring();
        return text;
    }

    Outcome calculate() {
        Outcome outcome;
        std::string test_message;
        if (!simplex_self_test(test_message)) {
            outcome.text = L"Симплекс-метод не прошёл контрольные задачи.\r\n" + widen(test_message);
            return outcome;
        }
        try {
            std::vector<std::filesystem::path> roots;
            roots.push_back(std::filesystem::current_path());
            const std::filesystem::path exe_dir = executable_directory();
            if (!exe_dir.empty()) {
                roots.push_back(exe_dir);
                if (exe_dir.has_parent_path()) {
                    roots.push_back(exe_dir.parent_path());
                }
            }

            const InputData data = load_input(roots);
            TrendLine trends[N_CROPS];
            for (int crop = 0; crop < N_CROPS; ++crop) {
                trends[crop] = fit_trend(data.history, crop, 2011, 2025);
            }

            double base_yield[N_YEARS][N_CROPS];
            double high_yield[N_YEARS][N_CROPS];
            double low_yield[N_YEARS][N_CROPS];
            double trend_yield[N_YEARS][N_CROPS];
            fill_bootstrap(data, 0, base_yield);
            fill_bootstrap(data, 1, high_yield);
            fill_bootstrap(data, -1, low_yield);

            bool trend_clamped = false;
            for (int slot = 0; slot < N_YEARS; ++slot) {
                for (int crop = 0; crop < N_CROPS; ++crop) {
                    double value = trend_at(trends[crop], PLAN_YEARS[slot]);
                    // Прямая на коротком ряде МОЖЕТ УЙТИ НИЖЕ 0. В задачу такой урожай не кладём:
                    // ЛОМАЕТСЯ ПОЧТИ ВСЕ:  и маржа, и перевод мощности завода из тонн в гектары
                    if (value < 0.2) {
                        value = 0.2;
                        trend_clamped = true;
                    }
                    trend_yield[slot][crop] = value;
                }
            }

            std::vector<Trajectory> trajectories;
            trajectories.push_back(run_trajectory(
                "base", "Базовый, медиана прогноза", data.crops, data.params, data.total_area, base_yield));
            trajectories.push_back(run_trajectory(
                "high", "Оптимистичный, верх 80% интервала", data.crops, data.params, data.total_area, high_yield));
            trajectories.push_back(run_trajectory(
                "low", "Пессимистичный, низ 80% интервала", data.crops, data.params, data.total_area, low_yield));
            Trajectory trend = run_trajectory(
                "trend", "Контрольный, линейный тренд", data.crops, data.params, data.total_area, trend_yield);
            if (trend_clamped) {
                trend.note = "Отрицательный тренд обрезан снизу значением 0,2 т/га.";
            }
            trajectories.push_back(trend);

            // Урожай оставляем базовым, дешевеют только картофель и овощи
            // Так видно, держится ли их расширение на высокой цене 2025 года
            std::vector<Crop> stressed = data.crops;
            stressed[POTATO].price_rub_t *= 0.7;
            stressed[VEGETABLES].price_rub_t *= 0.7;
            Trajectory stress = run_trajectory(
                "stress", "Ценовой стресс, картофель и овощи -30%", stressed, data.params, data.total_area, base_yield);
            stress.note = "Урожайность базовая. Проверяется, не развалится ли план при дешёвом картофеле и овощах.";
            trajectories.push_back(stress);
            std::vector<MarginalEffect> marginals;
            bool failed = false;
            for (const Trajectory& trajectory : trajectories) {
                if (!trajectory.ok) {
                    failed = true;
                }
                if (trajectory.key == "base" && trajectory.ok) {
                    marginals = marginal_effects(data.crops, data.params, trajectory.years[N_YEARS - 1], data.total_area);
                }
            }

            outcome.directory = results_directory();
            write_results(outcome.directory, trends, trajectories, marginals);
            outcome.ok = !failed;
            outcome.text = build_summary(trajectories, marginals, outcome.directory);
            if (failed) {
                outcome.text += L"\r\n\r\nОдин из сценариев не решён.";
                for (const Trajectory& trajectory : trajectories) {
                    if (!trajectory.ok) {
                        outcome.text += L"\r\n" + widen(trajectory.title) + L": " + widen(trajectory.error);
                    }
                }
            }
            return outcome;
        } catch (const std::exception& error) {
            outcome.text = L"Расчёт остановился.\r\n" + widen(error.what());
            return outcome;
        }
    }

    void drop_fonts() {
        if (g_title_font != nullptr) {
            DeleteObject(g_title_font);
            g_title_font = nullptr;
        }
        if (g_sub_font != nullptr) {
            DeleteObject(g_sub_font);
            g_sub_font = nullptr;
        }
        if (g_text_font != nullptr) {
            DeleteObject(g_text_font);
            g_text_font = nullptr;
        }
        if (g_button_font != nullptr) {
            DeleteObject(g_button_font);
            g_button_font = nullptr;
        }
    }

    HFONT make_font(HWND hwnd, int px, int weight, const wchar_t* face) {
        return CreateFontW(-scale_px(hwnd, px), 0, 0, 0, weight, FALSE, FALSE, FALSE, RUSSIAN_CHARSET,
            OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY, DEFAULT_PITCH | FF_DONTCARE, face);
    }

    void apply_fonts(HWND hwnd) {
        drop_fonts();
        g_title_font = make_font(hwnd, 26, FW_SEMIBOLD, L"Segoe UI");
        g_sub_font = make_font(hwnd, 15, FW_NORMAL, L"Segoe UI");
        g_text_font = make_font(hwnd, 16, FW_NORMAL, L"Consolas");
        g_button_font = make_font(hwnd, 15, FW_NORMAL, L"Segoe UI");
        SendMessageW(g_edit, WM_SETFONT, reinterpret_cast<WPARAM>(g_text_font), TRUE);
        SendMessageW(g_open_dir, WM_SETFONT, reinterpret_cast<WPARAM>(g_button_font), TRUE);
        SendMessageW(g_open_plan, WM_SETFONT, reinterpret_cast<WPARAM>(g_button_font), TRUE);
        SendMessageW(g_close, WM_SETFONT, reinterpret_cast<WPARAM>(g_button_font), TRUE);
    }

    void layout_window(HWND hwnd) {
        RECT client{};
        GetClientRect(hwnd, &client);
        const int margin = scale_px(hwnd, 16);
        const int header = scale_px(hwnd, HEADER_PX);
        const int button_h = scale_px(hwnd, 34);
        const int button_gap = scale_px(hwnd, 10);
        const int bottom = client.bottom - margin - button_h;
        const int edit_top = header + margin;
        MoveWindow(g_edit, margin, edit_top, client.right - 2 * margin, bottom - edit_top - margin, TRUE);

        const int close_w = scale_px(hwnd, 110);
        const int plan_w = scale_px(hwnd, 170);
        const int dir_w = scale_px(hwnd, 210);
        int x = client.right - margin - close_w;
        MoveWindow(g_close, x, bottom, close_w, button_h, TRUE);
        x -= button_gap + plan_w;
        MoveWindow(g_open_plan, x, bottom, plan_w, button_h, TRUE);
        x -= button_gap + dir_w;
        MoveWindow(g_open_dir, x, bottom, dir_w, button_h, TRUE);
    }

    void open_path(const std::filesystem::path& path) {
        if (path.empty()) {
            return;
        }
        ShellExecuteW(nullptr, L"open", path.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    }

    LRESULT CALLBACK window_proc(HWND hwnd, UINT message, WPARAM wparam, LPARAM lparam) {
        switch (message) {
        case WM_CREATE: {
            g_edit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"",
                WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL,
                0, 0, 0, 0, hwnd, nullptr, nullptr, nullptr);
            g_open_dir = CreateWindowExW(0, L"BUTTON", L"Открыть папку",
                WS_CHILD | WS_VISIBLE | WS_TABSTOP, 0, 0, 0, 0, hwnd,
                reinterpret_cast<HMENU>(static_cast<INT_PTR>(ID_OPEN_DIR)), nullptr, nullptr);
            g_open_plan = CreateWindowExW(0, L"BUTTON", L"Открыть plan.csv",
                WS_CHILD | WS_VISIBLE | WS_TABSTOP, 0, 0, 0, 0, hwnd,
                reinterpret_cast<HMENU>(static_cast<INT_PTR>(ID_OPEN_PLAN)), nullptr, nullptr);
            g_close = CreateWindowExW(0, L"BUTTON", L"Закрыть",
                WS_CHILD | WS_VISIBLE | WS_TABSTOP, 0, 0, 0, 0, hwnd,
                reinterpret_cast<HMENU>(static_cast<INT_PTR>(ID_CLOSE)), nullptr, nullptr);
            apply_fonts(hwnd);
            SetWindowTextW(g_edit, g_outcome.text.c_str());
            const BOOL enable = g_outcome.ok ? TRUE : FALSE;
            EnableWindow(g_open_dir, enable);
            EnableWindow(g_open_plan, enable);
            layout_window(hwnd);
            return 0;
        }
        case WM_SIZE:
            layout_window(hwnd);
            return 0;
        case WM_GETMINMAXINFO: {
            MINMAXINFO* info = reinterpret_cast<MINMAXINFO*>(lparam);
            info->ptMinTrackSize.x = scale_px(hwnd, 760);
            info->ptMinTrackSize.y = scale_px(hwnd, 520);
            return 0;
        }
        case WM_DPICHANGED: {
            const RECT* suggested = reinterpret_cast<RECT*>(lparam);
            SetWindowPos(hwnd, nullptr, suggested->left, suggested->top,
                suggested->right - suggested->left, suggested->bottom - suggested->top,
                SWP_NOZORDER | SWP_NOACTIVATE);
            apply_fonts(hwnd);
            layout_window(hwnd);
            return 0;
        }
        case WM_COMMAND:
            switch (LOWORD(wparam)) {
            case ID_OPEN_DIR:
                open_path(g_outcome.directory);
                return 0;
            case ID_OPEN_PLAN:
                open_path(g_outcome.directory / L"plan.csv");
                return 0;
            case ID_CLOSE:
                DestroyWindow(hwnd);
                return 0;
            default:
                break;
            }
            break;
        case WM_PAINT: {
            PAINTSTRUCT paint{};
            HDC dc = BeginPaint(hwnd, &paint);
            RECT client{};
            GetClientRect(hwnd, &client);
            RECT header = client;
            header.bottom = scale_px(hwnd, HEADER_PX);
            HBRUSH green = CreateSolidBrush(RGB(31, 107, 58));
            FillRect(dc, &header, green);
            DeleteObject(green);
            RECT body = client;
            body.top = header.bottom;
            HBRUSH paper = CreateSolidBrush(RGB(244, 246, 243));
            FillRect(dc, &body, paper);
            DeleteObject(paper);

            SetBkMode(dc, TRANSPARENT);
            SetTextColor(dc, RGB(255, 255, 255));
            RECT title = header;
            title.left += scale_px(hwnd, 18);
            title.top += scale_px(hwnd, 16);
            title.bottom = title.top + scale_px(hwnd, 34);
            SelectObject(dc, g_title_font);
            DrawTextW(dc, L"Оптимизация посевных площадей", -1, &title, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
            RECT subtitle = header;
            subtitle.left += scale_px(hwnd, 18);
            subtitle.top = title.bottom;
            subtitle.bottom = header.bottom - scale_px(hwnd, 8);
            SelectObject(dc, g_sub_font);
            DrawTextW(dc, L"Пензенская область, 2026–2028", -1, &subtitle, DT_LEFT | DT_SINGLELINE | DT_VCENTER);
            EndPaint(hwnd, &paint);
            return 0;
        }
        case WM_DESTROY:
            drop_fonts();
            PostQuitMessage(0);
            return 0;
        default:
            break;
        }
        return DefWindowProcW(hwnd, message, wparam, lparam);
    }
}

int WINAPI wWinMain(HINSTANCE instance, HINSTANCE, PWSTR, int show) {
    g_outcome = calculate();

    WNDCLASSEXW window_class{};
    window_class.cbSize = sizeof(window_class);
    window_class.lpfnWndProc = window_proc;
    window_class.hInstance = instance;
    window_class.hCursor = LoadCursorW(nullptr, IDC_ARROW);
    window_class.hbrBackground = CreateSolidBrush(RGB(244, 246, 243));
    window_class.lpszClassName = L"PenzaCropOpt";
    window_class.hIcon = LoadIconW(instance, MAKEINTRESOURCEW(1));
    window_class.hIconSm = window_class.hIcon;
    RegisterClassExW(&window_class);

    const int dpi = static_cast<int>(GetDpiForSystem());
    const int width = MulDiv(860, dpi, 96);
    const int height = MulDiv(700, dpi, 96);
    const int x = (GetSystemMetrics(SM_CXSCREEN) - width) / 2;
    const int y = (GetSystemMetrics(SM_CYSCREEN) - height) / 2;
    HWND hwnd = CreateWindowExW(0, window_class.lpszClassName, L"Оптимизация посевных площадей",
        WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN, x, y, width, height, nullptr, nullptr, instance, nullptr);
    ShowWindow(hwnd, show);
    UpdateWindow(hwnd);
    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        if (!IsDialogMessageW(hwnd, &message)) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }
    }
    return static_cast<int>(message.wParam);
}