#pragma once
#include "common.h"
#include <string>
#include <vector>

//Чем именно упёрлась площадь: в постоянный потолок, в годовой шаг или в завод
enum class LimitKind { Agronomic, Inertia, Capacity };

//Деньги одной культуры при заданных урожайности и площади.
struct CropMoney {
    double cost_ha = 0;
    double margin_ha = 0;
    double harvest_thous_t = 0;
    double revenue_mln = 0;
    double cost_mln = 0;
    double margin_mln = 0;
};

//Решение одного года. ref — площади, от которых считался годовой шаг
struct SolvedYear {
    int year = 0;
    double yield[N_CROPS]{};
    double area[N_CROPS]{};
    double ref[N_CROPS]{};
    double lo[N_CROPS]{};
    double hi[N_CROPS]{};
    LimitKind lo_kind[N_CROPS]{};
    LimitKind hi_kind[N_CROPS]{};
    bool ratio_active = false;// Подсолнечник вышел РОВНО НА ОДНУ ДОЛЮ ОТ ЗЕРНА
    bool ok = false;
    std::string error;
};

//Три года одного сценария. crops и params хранятся вместе с планом:
//у ценового стресса цены другие, и маржу нельзя считать по исходным культурам
struct Trajectory {
    std::string key;
    std::string title;
    std::string note;
    std::vector<Crop> crops;
    Params params;
    SolvedYear years[N_YEARS]{};
    bool ok = false;
    std::string error;
};

//Прирост маржи, если ослабить одно ограничение и пересчитать тот же год
//extra_margin_mln — разница с исходным планом, ещё без стоимости самого инструмента
struct MarginalEffect {
    std::string title;
    std::string meaning;
    double extra_margin_mln = 0;
    bool computed = false;
    std::string error;
};

//Затраты и маржа гектара, руб./га. Постоянная часть берётся с урожайности 2024 года,
//Переменная — с урожайности того года, который сейчас считается
double cost_per_ha(const Crop& crop, const Params& params, double yield_t_ha);
double margin_per_ha(const Crop& crop, const Params& params, double yield_t_ha);

CropMoney money_of(const Crop& crop, const Params& params, double yield_t_ha, double area_thous_ha);
double total_margin(const std::vector<Crop>& crops, const Params& params, const double yield[N_CROPS], const double area[N_CROPS]);

//Один год: пересечь шаги и агрономические границы, добавить мощность завода и долю подсолнечника, решить симплекс
//reference — база годового шага
SolvedYear optimize_year(const std::vector<Crop>& crops, const Params& params, int year, const double yield[N_CROPS], const double reference[N_CROPS], double total_area);

//2026 считается от факта 2025 года, 2027 — от плана 2026-го, 2028 — от плана 2027-го
Trajectory run_trajectory(const std::string& key, const std::string& title,
    const std::vector<Crop>& crops, const Params& params, double total_area,
    const double yields[N_YEARS][N_CROPS]);

//Четыре отдельных пересчёта года year: +1 тыс. га картофеля, +0,5 тыс. га овощей
std::vector<MarginalEffect> marginal_effects(const std::vector<Crop>& crops, const Params& params,
    const SolvedYear& year, double total_area);