#include "model.h"
#include "simplex.h"
#include <cmath>
#include <sstream>

double cost_per_ha(const Crop& crop, const Params& params, double yield_t_ha) {
    // Себестоимость_т * урожайность_2024 — это затраты гектара в год, когда её мерили
    // Дальше делим их на постоянную и переменную части, переменную пересчитываем на новый урожай
    const double cost_ha_base = crop.cost_rub_t * crop.yield_base;
    const double fixed = params.fixed_cost_share * cost_ha_base;
    const double variable = (1.0 - params.fixed_cost_share) * crop.cost_rub_t * yield_t_ha;
    return fixed + variable;
}

double margin_per_ha(const Crop& crop, const Params& params, double yield_t_ha) {
    return crop.price_rub_t * yield_t_ha - cost_per_ha(crop, params, yield_t_ha);
}

CropMoney money_of(const Crop& crop, const Params& params, double yield_t_ha, double area_thous_ha) {
    CropMoney money;
    money.cost_ha = cost_per_ha(crop, params, yield_t_ha);
    money.margin_ha = crop.price_rub_t * yield_t_ha - money.cost_ha;
    money.harvest_thous_t = area_thous_ha * yield_t_ha;
    // тыс. га * руб./га = тыс. руб. Деление на 1000 переводит это в млн руб
    // Тот же масштаб у сбора: тыс. т * руб./т тоже даёт тыс. руб
    money.revenue_mln = money.harvest_thous_t * crop.price_rub_t / 1000.0;
    money.cost_mln = area_thous_ha * money.cost_ha / 1000.0;
    money.margin_mln = money.revenue_mln - money.cost_mln;
    return money;
}

double total_margin(const std::vector<Crop>& crops, const Params& params,
                    const double yield[N_CROPS], const double area[N_CROPS]) {
    double sum = 0;
    for (int i = 0; i < N_CROPS; ++i) {
        sum += money_of(crops[static_cast<size_t>(i)], params, yield[i], area[i]).margin_mln;
    }
    return sum;
}

namespace {
    // ПОДНЯТЬ ГОДОВОЙ ПОТОЛК МАЛО: годовой шаг может по-прежнему не пускать площадь до новой цифры
    // Поэтому, если нужно, увеличиваем и inertia.
    void loosen_upper(Crop& crop, double reference, double target_hi) {
        if (target_hi > crop.area_max) {
            crop.area_max = target_hi;
        }
        if (reference > 1e-6) {
            const double needed = target_hi / reference - 1.0;
            if (needed > crop.inertia) {
                crop.inertia = needed + 1e-4;
            }
        }
    }
}

SolvedYear optimize_year(const std::vector<Crop>& crops, const Params& params, int year, const double yield[N_CROPS], const double reference[N_CROPS], double total_area) {
    SolvedYear solved;
    solved.year = year;
    for (int i = 0; i < N_CROPS; ++i) {
        solved.yield[i] = yield[i];
        solved.ref[i] = reference[i];
        if (yield[i] <= 0.05) {
            solved.error = "Слишком низкая урожайность у культуры " + crops[static_cast<size_t>(i)].name;
            return solved;
        }

        // Рабочий отрезок — пересечение годового шага и постоянного пола/потолка
        const double by_inertia_lo = reference[i] * (1.0 - crops[static_cast<size_t>(i)].inertia);
        const double by_inertia_hi = reference[i] * (1.0 + crops[static_cast<size_t>(i)].inertia);
        solved.lo[i] = by_inertia_lo > crops[static_cast<size_t>(i)].area_min ? by_inertia_lo
            : crops[static_cast<size_t>(i)].area_min;
        solved.lo_kind[i] = by_inertia_lo > crops[static_cast<size_t>(i)].area_min ? LimitKind::Inertia
            : LimitKind::Agronomic;
        solved.hi[i] = by_inertia_hi < crops[static_cast<size_t>(i)].area_max ? by_inertia_hi
            : crops[static_cast<size_t>(i)].area_max;
        solved.hi_kind[i] = by_inertia_hi < crops[static_cast<size_t>(i)].area_max ? LimitKind::Inertia
            : LimitKind::Agronomic;
        if (i == SUGAR) {
            // Завод ограничивает тонны, а переменная задачи — гектары
            // При высоком урожае тот же объём помещается на меньшей площади
            const double by_plant = params.beet_capacity_thous_t / yield[i];
            if (by_plant < solved.hi[i]) {
                solved.hi[i] = by_plant;
                solved.hi_kind[i] = LimitKind::Capacity;
            }
        }
        if (solved.lo[i] > solved.hi[i]) {
            // Шаг просит площадь выше жёсткого потолка. Потолок оставляем, пол подтягиваем к нему
            solved.lo[i] = solved.hi[i];
            solved.lo_kind[i] = solved.hi_kind[i];
        }
    }
    double sum_lo = 0;
    double sum_hi = 0;
    for (int i = 0; i < N_CROPS; ++i) {
        sum_lo += solved.lo[i];
        sum_hi += solved.hi[i];
    }
    if (sum_lo > total_area + 0.05) {
        solved.error = "Сумма минимальных площадей больше земельного фонда " + std::to_string(year);
        return solved;
    }
    if (sum_hi < total_area - 0.05) {
        solved.error = "Сумма максимальных площадей меньше земельного фонда " + std::to_string(year);
        return solved;
    }
    std::vector<LpConstraint> cons;
    {
        LpConstraint balance;
        balance.a.assign(N_CROPS, 1.0);
        balance.b = total_area;
        balance.type = LpType::EQ;
        cons.push_back(balance);
    }
    for (int i = 0; i < N_CROPS; ++i) {
        LpConstraint upper;
        upper.a.assign(N_CROPS, 0.0);
        upper.a[static_cast<size_t>(i)] = 1.0;
        upper.b = solved.hi[i];
        upper.type = LpType::LE;
        cons.push_back(upper);

        LpConstraint lower;
        lower.a.assign(N_CROPS, 0.0);
        lower.a[static_cast<size_t>(i)] = 1.0;
        lower.b = solved.lo[i];
        lower.type = LpType::GE;
        cons.push_back(lower);
    }
    {
        // x_подсолнечника - доля * x_зерна <= 0. Отдельные потолки этого не гарантируют:
        // ПОДЕЛЬ МОЖЕТ ОДНОВРЕМЕННО НАРСТИТЬ ПОДСОЛНЕЧНИК И ПРИ ЭТОМ СРЕЗАТЬ ЗЕРНО!!!!!
        LpConstraint ratio;
        ratio.a.assign(N_CROPS, 0.0);
        ratio.a[SUNFLOWER] = 1.0;
        ratio.a[GRAIN] = -params.sunflower_per_grain;
        ratio.b = 0;
        ratio.type = LpType::LE;
        cons.push_back(ratio);
    }

    std::vector<double> objective(N_CROPS);
    for (int i = 0; i < N_CROPS; ++i) {
        // руб./га / 1000 * тыс. га = млн руб., поэтому значение цели совпадает с суммой маржи
        objective[static_cast<size_t>(i)] =
            margin_per_ha(crops[static_cast<size_t>(i)], params, yield[i]) / 1000.0;
    }

    const SolveResult raw = maximize(objective, cons);
    if (raw.status == SolveStatus::Infeasible) {
        solved.error = "Симплекс: ограничения " + std::to_string(year) + " несовместны";
        return solved;
    }
    if (raw.status != SolveStatus::Optimal) {
        solved.error = "Симплекс (" + std::to_string(year) + "): " + raw.message;
        return solved;
    }

    double area_sum = 0;
    for (int i = 0; i < N_CROPS; ++i) {
        solved.area[i] = raw.x[static_cast<size_t>(i)];
        area_sum += solved.area[i];
        if (solved.area[i] < solved.lo[i] - 0.05 || solved.area[i] > solved.hi[i] + 0.05) {
            solved.error = "Решение вышло за границу площади: " + crops[static_cast<size_t>(i)].name;
            return solved;
        }
    }
    if (std::fabs(area_sum - total_area) > 0.05) {
        solved.error = "Сумма площадей не сошлась с земельным фондом";
        return solved;
    }
    const double sun_limit = params.sunflower_per_grain * solved.area[GRAIN];
    if (solved.area[SUNFLOWER] > sun_limit + 0.05) {
        solved.error = "Нарушено соотношение подсолнечника и зерновых";
        return solved;
    }
    solved.ratio_active = std::fabs(solved.area[SUNFLOWER] - sun_limit) <= 0.08;
    // Та же маржа, посчитанная формулами денег, а не симплекс-таблицей
    // Расхождение больше 0,5 млн руб - перепутаны единицы или знак цели
    const double recounted = total_margin(crops, params, solved.yield, solved.area);
    if (std::fabs(recounted - raw.objective) > 0.5) {
        std::ostringstream text;
        text << "Маржа симплекса (" << raw.objective << ") не сошлась с пересчётом (" << recounted << ")";
        solved.error = text.str();
        return solved;
    }
    solved.ok = true;
    return solved;
}

Trajectory run_trajectory(const std::string& key, const std::string& title,
    const std::vector<Crop>& crops, const Params& params, double total_area,
    const double yields[N_YEARS][N_CROPS]) {
    Trajectory trajectory;
    trajectory.key = key;
    trajectory.title = title;
    trajectory.crops = crops;
    trajectory.params = params;
    double reference[N_CROPS];
    for (int i = 0; i < N_CROPS; ++i) {
        reference[i] = crops[static_cast<size_t>(i)].area_2025;
    }
    trajectory.ok = true;
    for (int slot = 0; slot < N_YEARS; ++slot) {
        trajectory.years[slot] =
            optimize_year(crops, params, PLAN_YEARS[slot], yields[slot], reference, total_area);
        if (!trajectory.years[slot].ok) {
            trajectory.ok = false;
            trajectory.error = trajectory.years[slot].error;
            break;
        }
        // Следующий год отталкивается от уже выбранного плана, а не снова от факта 2025 года.
        for (int i = 0; i < N_CROPS; ++i) {
            reference[i] = trajectory.years[slot].area[i];
        }
    }
    return trajectory;
}

std::vector<MarginalEffect> marginal_effects(const std::vector<Crop>& crops, const Params& params, const SolvedYear& year, double total_area) {
    std::vector<MarginalEffect> effects;
    if (!year.ok) {
        return effects;
    }
    const double base = total_margin(crops, params, year.yield, year.area);
    struct Spec {
        const char* title;
        const char* meaning;
        int kind;
    };
    const Spec specs[] = {
        {"Картофель, потолок площади +1 тыс. га",
         "Хранилища, техника и люди, чтобы за год добавить тысячу гектаров картофеля.",
         0},
        {"Овощи, потолок площади +0,5 тыс. га",
         "То же для овощей открытого грунта: хранение, полив, рабочие руки.",
         1},
        {"Сахарные заводы, мощность +100 тыс. т",
         "Если заводы смогут принять на 100 тыс. т свёклы больше.",
         2},
        {"Севооборот подсолнечника 0,40 -> 0,45 к зерну",
         "Если допустить более плотный возврат подсолнечника на те же поля.",
         3},
    };
    for (const Spec& spec : specs) {
        MarginalEffect effect;
        effect.title = spec.title;
        effect.meaning = spec.meaning;
        std::vector<Crop> tweaked = crops;
        Params tweaked_params = params;
        if (spec.kind == 0) {
            loosen_upper(tweaked[POTATO], year.ref[POTATO], year.area[POTATO] + 1.0);
        } else if (spec.kind == 1) {
            loosen_upper(tweaked[VEGETABLES], year.ref[VEGETABLES], year.area[VEGETABLES] + 0.5);
        } else if (spec.kind == 2) {
            tweaked_params.beet_capacity_thous_t += 100.0;
        } else {
            tweaked_params.sunflower_per_grain += 0.05;
        }
        const SolvedYear variant =
            optimize_year(tweaked, tweaked_params, year.year, year.yield, year.ref, total_area);
        if (!variant.ok) {
            effect.error = variant.error;
            effects.push_back(effect);
            continue;
        }
        effect.computed = true;
        effect.extra_margin_mln = total_margin(tweaked, tweaked_params, variant.yield, variant.area) - base;
        effects.push_back(effect);
    }
    return effects;
}