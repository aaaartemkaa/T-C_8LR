#include "simplex.h"
#include <cmath>
#include <limits>
#include <sstream>
#include <string>
#include <vector>
namespace {
    constexpr double EPS = 1e-8;
    struct Row {
        std::vector<double> a;
        double b = 0;
        int type = -1;
    };
    std::string fmt_vec(const std::vector<double>& x) {
        std::ostringstream out;
        out.setf(std::ios::fixed);
        out.precision(6);
        out << "[";
        for (size_t i = 0; i < x.size(); ++i) {
            if (i) {
                out << " ";
            }
            out << x[i];
        }
        out << "]";
        return out.str();
    }
}

SolveResult maximize(const std::vector<double>& c, const std::vector<LpConstraint>& constraints) {
    SolveResult result;
    const int n = static_cast<int>(c.size());
    const int m = static_cast<int>(constraints.size());
    if (n <= 0 || m <= 0) {
        result.message = "Пустая задача линейного программирования";
        return result;
    }

    std::vector<Row> rows(static_cast<size_t>(m));
    for (int i = 0; i < m; ++i) {
        if (static_cast<int>(constraints[static_cast<size_t>(i)].a.size()) != n) {
            result.message = "Длина строки ограничений не совпала с числом переменных";
            return result;
        }
        rows[static_cast<size_t>(i)].a = constraints[static_cast<size_t>(i)].a;
        rows[static_cast<size_t>(i)].b = constraints[static_cast<size_t>(i)].b;
        if (constraints[static_cast<size_t>(i)].type == LpType::LE) {
            rows[static_cast<size_t>(i)].type = -1;
        } else if (constraints[static_cast<size_t>(i)].type == LpType::EQ) {
            rows[static_cast<size_t>(i)].type = 0;
        } else {
            rows[static_cast<size_t>(i)].type = 1;
        }
        // В таблице правая часть обязана быть >= 0. 
        // Отрицательную строку умножаем на -1 и переворачиваем знак неравенства
        if (rows[static_cast<size_t>(i)].b < -EPS) {
            for (double& value : rows[static_cast<size_t>(i)].a) {
                value = -value;
            }
            rows[static_cast<size_t>(i)].b = -rows[static_cast<size_t>(i)].b;
            rows[static_cast<size_t>(i)].type = -rows[static_cast<size_t>(i)].type;
        }
    }
    int n_slack = 0;
    int n_surplus = 0;
    int n_art = 0;
    for (const Row& row : rows) {
        if (row.type == -1) {
            ++n_slack;
        } else if (row.type == 1) {
            ++n_surplus;
            ++n_art;
        } else {
            ++n_art;
        }
    }

    // Столбцы таблицы: исходные x, слаки (<=), избытки (>=), искусственные, правая часть
    // <= сразу имеет базисный слак. >= и = стартуют с искусственной переменной,
    // иначе допустимого базиса нет и фаза 2 не с чего начинать
    const int n_col = n + n_slack + n_surplus + n_art;
    std::vector<std::vector<double>> table(static_cast<size_t>(m + 1), std::vector<double>(static_cast<size_t>(n_col + 1), 0.0));
    std::vector<int> basis(static_cast<size_t>(m), -1);
    const int slack_at = n;
    const int surplus_at = n + n_slack;
    const int art_at = n + n_slack + n_surplus;
    int slack_i = 0;
    int surplus_i = 0;
    int art_i = 0;

    for (int i = 0; i < m; ++i) {
        const Row& row = rows[static_cast<size_t>(i)];
        for (int j = 0; j < n; ++j) {
            table[static_cast<size_t>(i + 1)][static_cast<size_t>(j)] = row.a[static_cast<size_t>(j)];
        }
        table[static_cast<size_t>(i + 1)][static_cast<size_t>(n_col)] = row.b;
        if (row.type == -1) {
            const int column = slack_at + slack_i++;
            table[static_cast<size_t>(i + 1)][static_cast<size_t>(column)] = 1.0;
            basis[static_cast<size_t>(i)] = column;
        } else if (row.type == 1) {
            const int surplus = surplus_at + surplus_i++;
            const int artificial = art_at + art_i++;
            table[static_cast<size_t>(i + 1)][static_cast<size_t>(surplus)] = -1.0;
            table[static_cast<size_t>(i + 1)][static_cast<size_t>(artificial)] = 1.0;
            basis[static_cast<size_t>(i)] = artificial;
        } else {
            const int artificial = art_at + art_i++;
            table[static_cast<size_t>(i + 1)][static_cast<size_t>(artificial)] = 1.0;
            basis[static_cast<size_t>(i)] = artificial;
        }
    }

    auto pivot = [&](int pivot_row, int pivot_col) {
        const double pivot_value = table[static_cast<size_t>(pivot_row)][static_cast<size_t>(pivot_col)];
        for (int j = 0; j <= n_col; ++j) {
            table[static_cast<size_t>(pivot_row)][static_cast<size_t>(j)] /= pivot_value;
        }
        for (int i = 0; i <= m; ++i) {
            if (i == pivot_row) {
                continue;
            }
            const double factor = table[static_cast<size_t>(i)][static_cast<size_t>(pivot_col)];
            if (std::fabs(factor) <= EPS) {
                continue;
            }
            for (int j = 0; j <= n_col; ++j) {
                table[static_cast<size_t>(i)][static_cast<size_t>(j)] -=
                    factor * table[static_cast<size_t>(pivot_row)][static_cast<size_t>(j)];
            }
        }
        basis[static_cast<size_t>(pivot_row - 1)] = pivot_col;
        // Пыль после вычитания строк, иначе копит знак и ломает выбор опорного элемента
        for (int i = 0; i <= m; ++i) {
            for (int j = 0; j <= n_col; ++j) {
                if (std::fabs(table[static_cast<size_t>(i)][static_cast<size_t>(j)]) < 1e-12) {
                    table[static_cast<size_t>(i)][static_cast<size_t>(j)] = 0.0;
                }
            }
        }
    };

    auto run_phase = [&](bool phase1) -> int {
        for (int guard = 0; guard < 10000; ++guard) {
            ++result.iterations;
            std::vector<char> is_basic(static_cast<size_t>(n_col), 0);
            for (int basic_col : basis) {
                if (basic_col >= 0 && basic_col < n_col) {
                    is_basic[static_cast<size_t>(basic_col)] = 1;
                }
            }
            int enter = -1;
            for (int j = 0; j < n_col; ++j) {
                if (is_basic[static_cast<size_t>(j)]) {
                    continue;
                }
                if (!phase1 && j >= art_at) {
                    continue;
                }
                if (table[0][static_cast<size_t>(j)] > EPS) {
                    enter = j;// правило Бланда: не самый большой коэффициент, а первый подходящий
                    break;
                }
            }
            if (enter < 0) {
                return 0;
            }
            int leave = -1;
            double best_ratio = std::numeric_limits<double>::infinity();
            int best_basis = 0;
            for (int i = 1; i <= m; ++i) {
                const double column = table[static_cast<size_t>(i)][static_cast<size_t>(enter)];
                if (column <= EPS) {
                    continue;
                }
                const double ratio = table[static_cast<size_t>(i)][static_cast<size_t>(n_col)] / column;
                const int basic_col = basis[static_cast<size_t>(i - 1)];
                if (ratio < best_ratio - 1e-12 ||
                    (std::fabs(ratio - best_ratio) <= 1e-12 && (leave < 0 || basic_col < best_basis))) {
                    best_ratio = ratio;
                    leave = i;
                    best_basis = basic_col;
                }
            }
            if (leave < 0) {
                return 1;
            }
            pivot(leave, enter);
        }
        return 2;
    };
    if (n_art > 0) {
        // Фаза 1 максимизирует минус сумму искусственных. Пока искусственная в базисе,
        // её строку прибавляем к оценкам, чтобы у базисного столбца оценка стала нулевой
        for (int j = art_at; j < art_at + n_art; ++j) {
            table[0][static_cast<size_t>(j)] = -1.0;
        }
        for (int i = 0; i < m; ++i) {
            if (basis[static_cast<size_t>(i)] >= art_at) {
                for (int j = 0; j <= n_col; ++j) {
                    table[0][static_cast<size_t>(j)] += table[static_cast<size_t>(i + 1)][static_cast<size_t>(j)];
                }
            }
        }
        const int phase1 = run_phase(true);
        if (phase1 == 1) {
            result.status = SolveStatus::Unbounded;
            result.message = "Фаза 1 не ограничена";
            return result;
        }
        if (phase1 == 2) {
            result.status = SolveStatus::Error;
            result.message = "Фаза 1: превышен лимит итераций";
            return result;
        }
        double artificial_left = 0;
        for (int i = 0; i < m; ++i) {
            if (basis[static_cast<size_t>(i)] >= art_at) {
                artificial_left += table[static_cast<size_t>(i + 1)][static_cast<size_t>(n_col)];
            }
        }
        // Ненулевые искусственные в базисе значат, что исходные ограничения несовместны.
        if (artificial_left > 1e-6) {
            result.status = SolveStatus::Infeasible;
            result.message = "Ограничения несовместны";
            return result;
        }
        for (double& value : table[0]) {
            value = 0;
        }
    }

    // Фаза 2. В строке оценок сначала стоит сама цель. Если x[j] уже базисная,
    // её оценку обнуляем, иначе симплекс попытается ввести переменную, которая уже в базисе
    for (int j = 0; j < n; ++j) {
        table[0][static_cast<size_t>(j)] = c[static_cast<size_t>(j)];
    }
    for (int i = 0; i < m; ++i) {
        const int basic_col = basis[static_cast<size_t>(i)];
        if (basic_col < 0 || basic_col >= n) {
            continue;
        }
        const double coef = table[0][static_cast<size_t>(basic_col)];
        if (std::fabs(coef) <= EPS) {
            continue;
        }
        for (int j = 0; j <= n_col; ++j) {
            table[0][static_cast<size_t>(j)] -= coef * table[static_cast<size_t>(i + 1)][static_cast<size_t>(j)];
        }
    }

    const int phase2 = run_phase(false);
    if (phase2 == 1) {
        result.status = SolveStatus::Unbounded;
        result.message = "Целевая функция не ограничена сверху";
        return result;
    }
    if (phase2 == 2) {
        result.status = SolveStatus::Error;
        result.message = "Фаза 2: превышен лимит итераций";
        return result;
    }
    std::vector<char> is_basic(static_cast<size_t>(n_col), 0);
    for (int basic_col : basis) {
        if (basic_col >= 0 && basic_col < n_col) {
            is_basic[static_cast<size_t>(basic_col)] = 1;
        }
    }
    for (int j = 0; j < n_col; ++j) {
        if (j >= art_at || is_basic[static_cast<size_t>(j)]) {
            continue;
        }
        if (table[0][static_cast<size_t>(j)] > 1e-5) {
            result.status = SolveStatus::Error;
            result.message = "Симплекс остановился раньше оптимума";
            return result;
        }
    }

    result.x.assign(static_cast<size_t>(n), 0.0);
    for (int i = 0; i < m; ++i) {
        const int basic_col = basis[static_cast<size_t>(i)];
        if (basic_col >= 0 && basic_col < n) {
            double value = table[static_cast<size_t>(i + 1)][static_cast<size_t>(n_col)];
            if (std::fabs(value) < 1e-9) {
                value = 0;
            }
            result.x[static_cast<size_t>(basic_col)] = value;
        }
    }
    // Строка оценок хранит минус достигнутой цели: каждый шаг вычитает прирост из правой части
    result.objective = -table[0][static_cast<size_t>(n_col)];
    result.status = SolveStatus::Optimal;
    return result;
}

bool simplex_self_test(std::string& message) {
    std::ostringstream errors;
    int failed = 0;
    auto expect = [&](const char* name, const SolveResult& solved, SolveStatus status,
                      const std::vector<double>& x, double objective) {
        bool ok = solved.status == status;
        if (ok && status == SolveStatus::Optimal) {
            if (solved.x.size() != x.size() || std::fabs(solved.objective - objective) > 1e-4) {
                ok = false;
            }
            for (size_t i = 0; ok && i < x.size(); ++i) {
                if (std::fabs(solved.x[i] - x[i]) > 1e-4) {
                    ok = false;
                }
            }
        }
        if (!ok) {
            ++failed;
            errors << name << ": status=" << static_cast<int>(solved.status) 
                << " obj=" << solved.objective << " x=" << fmt_vec(solved.x)
                << " (" << solved.message << ")\n";
        }
    };

    {
        std::vector<LpConstraint> cons(3);
        cons[0] = {{1, 0}, 4, LpType::LE};
        cons[1] = {{0, 1}, 6, LpType::LE};
        cons[2] = {{3, 2}, 18, LpType::LE};
        expect("границы", maximize({3, 5}, cons), SolveStatus::Optimal, {2, 6}, 36);
    }
    {
        std::vector<LpConstraint> cons(4);
        cons[0] = {{1, 1}, 10, LpType::LE};
        cons[1] = {{1, 0}, 8, LpType::LE};
        cons[2] = {{1, 0}, 4, LpType::GE};
        cons[3] = {{0, 1}, 2, LpType::GE};
        expect("нижние границы", maximize({2, 3}, cons), SolveStatus::Optimal, {4, 6}, 26);
    }
    {
        std::vector<LpConstraint> cons(2);
        cons[0] = {{1, 1}, 10, LpType::EQ};
        cons[1] = {{-0.4, 1}, 0, LpType::LE};
        const double sun = 10.0 * 0.4 / 1.4;
        const double grain = 10.0 - sun;
        expect("равенство и пропорция", maximize({1, 10}, cons), SolveStatus::Optimal,
               {grain, sun}, grain + 10.0 * sun);
    }
    {
        std::vector<LpConstraint> cons(2);
        cons[0] = {{1}, 5, LpType::GE};
        cons[1] = {{1}, 2, LpType::LE};
        expect("несовместна", maximize({1}, cons), SolveStatus::Infeasible, {}, 0);
    }
    {
        std::vector<LpConstraint> cons(1);
        cons[0] = {{1}, 1, LpType::GE};
        expect("не ограничена", maximize({1}, cons), SolveStatus::Unbounded, {}, 0);
    }

    if (failed) {
        message = errors.str();
        return false;
    }
    message = "пройдена";
    return true;
}