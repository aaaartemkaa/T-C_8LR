#include "report.h"
#include <fstream>
#include <sstream>
namespace {

    std::string num(double value, int precision) {
        std::ostringstream out;
        out.setf(std::ios::fixed);
        out.precision(precision);
        out << value;
        std::string text = out.str();
        for (char& symbol : text) {
            if (symbol == '.') {
                symbol = ',';
            }
        }
        return text;
    }

    void write_plan(const std::filesystem::path& path, const std::vector<Trajectory>& trajectories) {
        std::ofstream csv(path, std::ios::binary);
        csv << "\xEF\xBB\xBF";
        csv << "сценарий;год;культура;площадь_тыс_га;урожайность_т_га;сбор_тыс_т;"
            "выручка_млн_руб;затраты_млн_руб;маржа_млн_руб\n";
        for (const Trajectory& trajectory : trajectories) {
            for (int slot = 0; slot < N_YEARS; ++slot) {
                const SolvedYear& year = trajectory.years[slot];
                if (!year.ok) {
                    continue;
                }
                for (int i = 0; i < N_CROPS; ++i) {
                    const CropMoney money = money_of(
                        trajectory.crops[static_cast<size_t>(i)], trajectory.params, year.yield[i], year.area[i]);
                    csv << trajectory.title << ';' << year.year << ';'
                        << trajectory.crops[static_cast<size_t>(i)].name << ';'
                        << num(year.area[i], 2) << ';' << num(year.yield[i], 2) << ';'
                        << num(money.harvest_thous_t, 1) << ';' << num(money.revenue_mln, 1) << ';'
                        << num(money.cost_mln, 1) << ';' << num(money.margin_mln, 1) << '\n';
                }
            }
        }
    }

    void write_trend(const std::filesystem::path& path, const TrendLine trends[N_CROPS]) {
        std::ofstream csv(path, std::ios::binary);
        csv << "\xEF\xBB\xBF";
        csv << "культура;a;b;r2;mape_проц;урожай_2026;урожай_2027;урожай_2028\n";
        for (int i = 0; i < N_CROPS; ++i) {
            const TrendLine& line = trends[i];
            csv << crop_id(i) << ';'
                << num(line.intercept, 4) << ';' << num(line.slope, 4) << ';'
                << num(line.r2, 4) << ';' << num(line.mape, 2) << ';'
                << num(trend_at(line, 2026), 2) << ';'
                << num(trend_at(line, 2027), 2) << ';'
                << num(trend_at(line, 2028), 2) << '\n';
        }
    }

    void write_effects(const std::filesystem::path& path, const std::vector<MarginalEffect>& marginals) {
        std::ofstream csv(path, std::ios::binary);
        csv << "\xEF\xBB\xBF";
        csv << "изменение;прирост_маржи_млн_руб\n";
        for (const MarginalEffect& effect : marginals) {
            csv << effect.title << ';';
            if (effect.computed) {
                csv << num(effect.extra_margin_mln, 1);
            }
            csv << '\n';
        }
    }
}

void write_results(const std::filesystem::path& directory, 
    const TrendLine trends[N_CROPS], const std::vector<Trajectory>& trajectories, 
    const std::vector<MarginalEffect>& marginals) {
    std::filesystem::create_directories(directory);
    write_plan(directory / "plan.csv", trajectories);
    write_trend(directory / "trend.csv", trends);
    write_effects(directory / "effects.csv", marginals);
}