#pragma once
#include "forecast.h"
#include "model.h"
#include <filesystem>
#include <vector>
// Пишет: план площадей, коэффициенты тренда и прирост маржи
void write_results(const std::filesystem::path& directory, 
    const TrendLine trends[N_CROPS],
    const std::vector<Trajectory>& trajectories,
    const std::vector<MarginalEffect>& marginals);