﻿#define MyAppName "Оптимизация посевных площадей"
#define MyAppVersion "1.0"
#define MyAppExe "PenzaCropOpt.exe"

[Setup]
AppId={{A4C8E1D2-7B33-4F19-9C55-2E6D8A1B4F70}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=Индивидуальное задание, тема 3
DefaultDirName={localappdata}\PenzaCropOpt
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=..
OutputBaseFilename=Установщик
SetupIconFile=..\src\app.ico
UninstallDisplayIcon={app}\{#MyAppExe}
UninstallDisplayName={#MyAppName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
VersionInfoVersion=1.0.0.0
VersionInfoDescription=Установщик программы оптимизации посевных площадей

[Languages]
Name: "russian"; MessagesFile: "compiler:Languages\Russian.isl"

[Files]
Source: "..\bin\x64\Release\{#MyAppExe}"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\bin\x64\Release\data\*"; DestDir: "{app}\data"; Flags: ignoreversion recursesubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; WorkingDir: "{app}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; WorkingDir: "{app}"

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "Запустить программу"; Flags: nowait postinstall skipifsilent
