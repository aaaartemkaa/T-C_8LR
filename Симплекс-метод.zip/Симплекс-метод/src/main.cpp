// Решатель: двухфазный симплекс и проверка на известных задачах
#include "simplex.h"
#define NOMINMAX
#include <windows.h>
#include <iostream>
#include <string>

namespace {
    const char* status_name(SolveStatus status) {
        switch (status) {
        case SolveStatus::Optimal: return "оптимум";
        case SolveStatus::Infeasible: return "нет решения";
        case SolveStatus::Unbounded: return "цель не ограничена";
        case SolveStatus::Error: return "ошибка";
        }
        return "ошибка";
    }
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    std::string message;
    std::cout << "Симплекс-метод\n";
    if (!simplex_self_test(message)) {
        std::cerr << "Контрольные задачи не сошлись.\n" << message;
        return 1;
    }
    std::cout << "Контрольные задачи: " << message << "\n\n";
    // max 3x + 5y при x <= 4, y <= 6, 3x + 2y <= 18. Просто пример!!!
    std::vector<LpConstraint> constraints(3);
    constraints[0] = {{1, 0}, 4, LpType::LE};
    constraints[1] = {{0, 1}, 6, LpType::LE};
    constraints[2] = {{3, 2}, 18, LpType::LE};
    const SolveResult solved = maximize({3, 5}, constraints);
    std::cout << "Пример: max 3x + 5y\n";
    std::cout << "x <= 4,  y <= 6,  3x + 2y <= 18\n";
    std::cout << "Статус: " << status_name(solved.status) << "\n";
    if (solved.status == SolveStatus::Optimal && solved.x.size() == 2) {
        std::cout.setf(std::ios::fixed);
        std::cout.precision(0);
        std::cout << "x = " << solved.x[0] << ", y = " << solved.x[1] << "\n";
        std::cout << "Цель = " << solved.objective << "\n";
    }
    std::cout << "Итераций: " << solved.iterations << "\n";
    return solved.status == SolveStatus::Optimal ? 0 : 1;
}
