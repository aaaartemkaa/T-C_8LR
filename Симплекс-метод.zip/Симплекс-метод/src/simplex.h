#pragma once
#include <string>
#include <vector>
// Двухфазный симплекс: максимум c*x при x >= 0
// Ограничение записывается как sum(a[j] * x[j]) ? b
// Фаза 1 выгоняет искусственные переменные и проверяет совместность.
// Фаза 2 максимизирует исходную цель. Столбец для ввода берётся по Бланду —
// первый с положительной оценкой, ЧТОБЫ ВЫРОЖДАЮЩИЙ БАЗИС НЕ ЗАЦИКЛИЛСЯ

enum class LpType {
    LE,// <=
    GE,// >=
    EQ // =
};

struct LpConstraint {
    std::vector<double> a;
    double b = 0;
    LpType type = LpType::LE;
};

enum class SolveStatus {
    Optimal,// найден максимум
    Infeasible,// система ограничений пуста
    Unbounded,// цель можно растить бесконечно
    Error// размерности не сошлись или кончился лимит итераций
};

struct SolveResult {
    SolveStatus status = SolveStatus::Error;
    std::vector<double> x;// только исходные переменные, ДОП. СТОБЦЫ СЮДА НЕ ПОПАДАЮТ
    double objective = 0;// c*x. в задаче площадей это млн руб. маржи
    int iterations = 0;
    std::string message;
};

SolveResult maximize(const std::vector<double>& c, const std::vector<LpConstraint>& constraints);
bool simplex_self_test(std::string& message);