#pragma once
#include "common.h"
#include <vector>
// Прямая МНК:
// урожайность = intercept + slope * (год - origin)
// origin — первый год окна (у нас 2011), поэтому intercept равен уровню на 2011 год
// R2 показывает, какая доля разброса легла на прямую. MAPE — средняя относительная ошибка на тех же годах
struct TrendLine {
    double intercept = 0;
    double slope = 0;
    double r2 = 0;
    double mape = 0;
    int n = 0;
    int origin = 2011;
};

// Окно включительно. Годы вне [year_from, year_to] в оценку не входят:
// ряд до 2011 года другой по технологиям, мешать его с современным нельзя
TrendLine fit_trend(const std::vector<YearRow>& history, int crop, int year_from, int year_to);
double trend_at(const TrendLine& line, int year);