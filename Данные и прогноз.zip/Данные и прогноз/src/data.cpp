#include "data.h"
#include <cmath>
#include <fstream>
#include <map>
#include <sstream>

namespace {
    std::string trim(std::string text) {
        while (!text.empty() && (text.back() == '\r' || text.back() == ' ' || text.back() == '\t')) {
            text.pop_back();
        }
        size_t begin = 0;
        while (begin < text.size() && (text[begin] == ' ' || text[begin] == '\t')) {
            ++begin;
        }
        if (begin) {
            text.erase(0, begin);
        }
        // Excel ИНОГДА СОХРАНЕТ CSV С НЕВИДИМОЙ МЕТКОЙ UTF-8 В НАЧАЛЕ!!!!
        // ЕСЛИ ЕЕ НЕ СНЯТЬ, СТОБЕЦ year НЕ НАЙДЕТСЯ!!!!!!
        if (text.size() >= 3 &&
            static_cast<unsigned char>(text[0]) == 0xEF &&
            static_cast<unsigned char>(text[1]) == 0xBB &&
            static_cast<unsigned char>(text[2]) == 0xBF) {
            text.erase(0, 3);
        }
        return text;
    }

    std::vector<std::string> split_semicolon(const std::string& line) {
        std::vector<std::string> parts;
        std::string current;
        for (char ch : line) {
            if (ch == ';') {
                parts.push_back(trim(current));
                current.clear();
            }
            else {
                current.push_back(ch);
            }
        }
        parts.push_back(trim(current));
        return parts;
    }

    double to_double(const std::string& text, const std::string& where) {
        try {
            size_t used = 0;
            const double value = std::stod(text, &used);
            if (used != text.size()) {
                throw std::runtime_error("хвост");
            }
            return value;
        }
        catch (const std::exception&) {
            throw std::runtime_error("Не число (" + text + ") в " + where);
        }
    }

    int to_int(const std::string& text, const std::string& where) {
        try {
            size_t used = 0;
            const int value = std::stoi(text, &used);
            if (used != text.size()) {
                throw std::runtime_error("хвост");
            }
            return value;
        }
        catch (const std::exception&) {
            throw std::runtime_error("Не целое (" + text + ") в " + where);
        }
    }

    std::filesystem::path find_file(const std::vector<std::filesystem::path>& roots, const std::string& name) {
        for (const std::filesystem::path& root : roots) {
            const std::filesystem::path direct = root / name;
            if (std::filesystem::exists(direct)) {
                return direct;
            }
            const std::filesystem::path nested = root / "data" / name;
            if (std::filesystem::exists(nested)) {
                return nested;
            }
        }
        throw std::runtime_error(
            "Не найден файл data/" + name +
            ". Запускайте программу из папки проекта");
    }

    std::vector<std::string> read_lines(const std::filesystem::path& path) {
        std::ifstream input(path);
        if (!input) {
            throw std::runtime_error("Не удалось открыть " + path.filename().string());
        }
        std::vector<std::string> lines;
        std::string line;
        while (std::getline(input, line)) {
            line = trim(line);
            if (line.empty() || line[0] == '#') {
                continue;
            }
            lines.push_back(line);
        }
        return lines;
    }
}

InputData load_input(const std::vector<std::filesystem::path>& roots) {
    InputData data;
    data.crops.assign(N_CROPS, Crop{});
    const auto economy_lines = read_lines(find_file(roots, "economics.csv"));
    bool seen[N_CROPS]{};
    for (const std::string& line : economy_lines) {
        const std::vector<std::string> parts = split_semicolon(line);
        if (parts.empty()) {
            continue;
        }
        if (parts[0] == "param") {
            if (parts.size() != 3) {
                throw std::runtime_error("Строка param в economics.csv должна содержать 3 поля");
            }
            const double value = to_double(parts[2], "economics.csv");
            if (parts[1] == "fixed_cost_share") {
                data.params.fixed_cost_share = value;
            } else if (parts[1] == "beet_capacity_thous_t") {
                data.params.beet_capacity_thous_t = value;
            } else if (parts[1] == "sunflower_per_grain") {
                data.params.sunflower_per_grain = value;
            } else {
                throw std::runtime_error("Неизвестный параметр " + parts[1]);
            }
            continue;
        }
        if (parts[0] != "crop" || parts.size() != 10) {
            throw std::runtime_error("Непонятная строка в economics.csv: " + line);
        }
        const int index = crop_index(parts[1]);
        if (index < 0) {
            throw std::runtime_error("Неизвестная культура " + parts[1]);
        }
        Crop& crop = data.crops[static_cast<size_t>(index)];
        crop.id = parts[1];
        crop.name = parts[2];
        crop.price_rub_t = to_double(parts[3], crop.id);
        crop.cost_rub_t = to_double(parts[4], crop.id);
        crop.yield_base = to_double(parts[5], crop.id);
        crop.area_2025 = to_double(parts[6], crop.id);
        crop.area_min = to_double(parts[7], crop.id);
        crop.area_max = to_double(parts[8], crop.id);
        crop.inertia = to_double(parts[9], crop.id);
        if (crop.price_rub_t <= 0 || crop.cost_rub_t <= 0 || crop.yield_base <= 0) {
            throw std::runtime_error("Цена, себестоимость и базовая урожайность должны быть больше нуля: " + crop.id);
        }
        if (crop.area_min > crop.area_2025 || crop.area_2025 > crop.area_max) {
            throw std::runtime_error("Площадь 2025 года вне границ: " + crop.name);
        }
        if (crop.inertia < 0 || crop.inertia > 1.0) {
            throw std::runtime_error("Шаг inertia должен быть от 0 до 1: " + crop.name);
        }
        seen[index] = true;
        data.total_area += crop.area_2025;
    }
    for (int i = 0; i < N_CROPS; ++i) {
        if (!seen[i]) {
            throw std::runtime_error(std::string("В economics.csv нет культуры ") + crop_id(i));
        }
    }
    if (data.params.fixed_cost_share < 0 || data.params.fixed_cost_share > 1) {
        throw std::runtime_error("fixed_cost_share должен быть от 0 до 1");
    }
    if (data.params.beet_capacity_thous_t <= 0 || data.params.sunflower_per_grain <= 0) {
        throw std::runtime_error("Мощность заводов и доля подсолнечника должны быть больше нуля");
    }
    if (data.crops[SUNFLOWER].area_2025 >
        data.params.sunflower_per_grain * data.crops[GRAIN].area_2025 + 0.05) {
        throw std::runtime_error("Факт 2025 года уже нарушает соотношение подсолнечника и зерновых");
    }

    const auto history_lines = read_lines(find_file(roots, "yield_area.csv"));
    if (history_lines.size() < 2) {
        throw std::runtime_error("yield_area.csv пустой");
    }
    const std::vector<std::string> header = split_semicolon(history_lines[0]);
    std::map<std::string, int> column;
    for (int i = 0; i < static_cast<int>(header.size()); ++i) {
        column[header[static_cast<size_t>(i)]] = i;
    }
    const char* required[] = {
        "year", "p_grain", "p_sugar", "p_sunflower", "p_potato", "p_vegetables",
        "s_grain", "s_sugar", "s_sunflower", "s_potato", "s_vegetables"
    };
    for (const char* name : required) {
        if (!column.count(name)) {
            throw std::runtime_error(std::string("В yield_area.csv нет столбца ") + name);
        }
    }
    const int yield_col[N_CROPS] = {
        column["p_grain"], column["p_sugar"], column["p_sunflower"], column["p_potato"], column["p_vegetables"]
    };
    const int area_col[N_CROPS] = {
        column["s_grain"], column["s_sugar"], column["s_sunflower"], column["s_potato"], column["s_vegetables"]
    };

    for (size_t line_i = 1; line_i < history_lines.size(); ++line_i) {
        const std::vector<std::string> parts = split_semicolon(history_lines[line_i]);
        if (static_cast<int>(parts.size()) < static_cast<int>(header.size())) {
            throw std::runtime_error("Короткая строка в yield_area.csv, год около строки " + std::to_string(line_i + 1));
        }
        YearRow row;
        row.year = to_int(parts[static_cast<size_t>(column["year"])], "yield_area.csv");
        for (int crop = 0; crop < N_CROPS; ++crop) {
            row.yield[crop] = to_double(parts[static_cast<size_t>(yield_col[crop])], "yield_area.csv");
            row.area[crop] = to_double(parts[static_cast<size_t>(area_col[crop])], "yield_area.csv");
        }
        data.history.push_back(row);
    }

    const YearRow* year_2024 = nullptr;
    const YearRow* year_2025 = nullptr;
    for (const YearRow& row : data.history) {
        if (row.year == 2024) {
            year_2024 = &row;
        }
        if (row.year == 2025) {
            year_2025 = &row;
        }
    }
    if (!year_2024 || !year_2025) {
        throw std::runtime_error("В ряде нет 2024 или 2025 года");
    }
    for (int i = 0; i < N_CROPS; ++i) {
        // Затраты считаются от урожайности 2024 года, площади плана — от 2025-го
        // Если 2 файла разъехались, МАРЖА И "к 2025" В ОТЧЕТЕ БУДУТ ПРО РАЗНЫЕ ВЕЩИ!!!!!
        if (std::fabs(year_2024->yield[i] - data.crops[static_cast<size_t>(i)].yield_base) > 0.02) {
            throw std::runtime_error("Базовая урожайность в economics.csv не совпала с 2024 годом: " +
                data.crops[static_cast<size_t>(i)].name);
        }
        if (std::fabs(year_2025->area[i] - data.crops[static_cast<size_t>(i)].area_2025) > 0.2) {
            throw std::runtime_error("Площадь 2025 года в economics.csv не совпала с рядом: " +
                data.crops[static_cast<size_t>(i)].name);
        }
    }

    bool got[N_CROPS][N_YEARS]{};
    const auto forecast_lines = read_lines(find_file(roots, "forecast_bootstrap.csv"));
    for (const std::string& line : forecast_lines) {
        const std::vector<std::string> parts = split_semicolon(line);
        if (parts.size() != 5) {
            throw std::runtime_error("Строка прогноза должна содержать 5 полей: " + line);
        }
        const int index = crop_index(parts[0]);
        const int year = to_int(parts[1], "forecast_bootstrap.csv");
        if (index < 0 || year < 2026 || year > 2028) {
            throw std::runtime_error("Плохой ключ прогноза: " + line);
        }
        const int slot = year - 2026;
        Band& band = data.bootstrap[index][slot];
        band.low = to_double(parts[2], "forecast_bootstrap.csv");
        band.median = to_double(parts[3], "forecast_bootstrap.csv");
        band.high = to_double(parts[4], "forecast_bootstrap.csv");
        if (!(band.low <= band.median && band.median <= band.high) || band.low <= 0) {
            throw std::runtime_error("Интервал прогноза перепутан: " + line);
        }
        got[index][slot] = true;
    }
    for (int crop = 0; crop < N_CROPS; ++crop) {
        for (int year = 0; year < N_YEARS; ++year) {
            if (!got[crop][year]) {
                throw std::runtime_error(std::string("Нет прогноза ") + crop_id(crop) + " на " + std::to_string(2026 + year));
            }
        }
    }
    return data;
}