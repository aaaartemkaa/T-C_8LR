#pragma once
#include <string>
// Индекс культуры один и тот же во всех массивах:
// 0 — зерно, 1 — свёкла, 2 — подсолнечник, 3 — картофель, 4 — овощи.
// Площади хранятся в тыс. га, урожайность в т/га. Деньги подписаны в полях ниже.

constexpr int N_CROPS = 5;
constexpr int N_YEARS = 3;
constexpr int PLAN_YEARS[N_YEARS] = {2026, 2027, 2028};

enum CropId {
    GRAIN = 0,
    SUGAR = 1,
    SUNFLOWER = 2,
    POTATO = 3,
    VEGETABLES = 4
};

//Одна культура и все коэффициенты, которые по ней читаются из economics.csv
struct Crop {
    std::string id;
    std::string name;
    double price_rub_t = 0;// цена реализации, руб./т
    double cost_rub_t = 0;// себестоимость 2024 года, руб./т
    double yield_base = 0;// урожайность того же 2024 года, т/га: на ней сидит расчёт затрат
    double area_2025 = 0;// фактическая площадь, тыс. га; от неё стартует план
    double area_min = 0;// агрономический пол, тыс. га
    double area_max = 0;// агрономический потолок, тыс. га
    double inertia = 0;// 0.08 - за один год площадь можно сдвинуть не больше чем на 8%
};

struct Params {
    // Доля затрат гектара, не зависящая от собранного урожая (обработка, семена, защита)
    double fixed_cost_share = 0.65;
    // Сколько свёклы способны принять заводы, тыс. т
    double beet_capacity_thous_t = 3200;
    // x_подсолнечника <= sunflower_per_grain * x_зерна
    // ИНАЧЕ МОДЕЛЬ ВЫТЕСНИТ ЗЕРНО, без которого подсолнечник нечем чередовать
    double sunflower_per_grain = 0.40;
};

//Один год исторического ряда. Индекс массива - CropId
struct YearRow {
    int year = 0;
    double yield[N_CROPS]{};
    double area[N_CROPS]{};
};

//Прогноз на один год из таблицы 10: низ и верх 80% интервала и медиана, т/га
struct Band {
    double low = 0;
    double median = 0;
    double high = 0;
};

inline const char* crop_id(int index) {
    static const char* ids[N_CROPS] = {
        "grain", "sugar", "sunflower", "potato", "vegetables"
    };
    return ids[index];
}

//Ключ из CSV -> CropId. Строки файла могут идти в любом порядке
//Неизвестный ключ даёт -1, загрузчик на этом останавливается
inline int crop_index(const std::string& id) {
    for (int i = 0; i < N_CROPS; ++i) {
        if (id == crop_id(i)) {
            return i;
        }
    }
    return -1;
}