// Данные и прогноз: ряд 1990–2025, цены, себестоимость и прямая МНК.
#include "data.h"
#include "forecast.h"
#define NOMINMAX
#include <windows.h>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

    std::filesystem::path executable_directory() {
        wchar_t buffer[MAX_PATH];
        const DWORD length = GetModuleFileNameW(nullptr, buffer, MAX_PATH);
        if (length == 0 || length >= MAX_PATH) {
            return {};
        }
        return std::filesystem::path(buffer).parent_path();
    }

    const char* names[N_CROPS] = {
        "Зерно", "Свёкла", "Подсолнечник", "Картофель", "Овощи"
    };

    int letters(const std::string& text) {
        int count = 0;
        for (unsigned char symbol : text) {
            if ((symbol & 0xC0) != 0x80) {
                ++count;
            }
        }
        return count;
    }

    std::string column(const std::string& text, int width) {
        std::string out = text;
        const int gap = width - letters(text);
        if (gap > 0) {
            out.append(static_cast<size_t>(gap), ' ');
        }
        return out;
    }
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    try {
        std::vector<std::filesystem::path> roots;
        roots.push_back(std::filesystem::current_path());
        const std::filesystem::path exe_dir = executable_directory();
        if (!exe_dir.empty()) {
            roots.push_back(exe_dir);
        }
        const InputData data = load_input(roots);

        std::cout << "Данные и прогноз урожайности\n";
        std::cout << "Лет в ряде: " << data.history.size() << "\n";
        std::cout << "Земельный фонд пяти культур, 2025: " << data.total_area << " тыс. га\n\n";

        std::cout << std::fixed << std::setprecision(0);
        std::cout << column("Культура", 16) << "цена      себестоимость  площадь 2025\n";
        for (int crop = 0; crop < N_CROPS; ++crop) {
            const Crop& item = data.crops[static_cast<size_t>(crop)];
            std::cout << column(names[crop], 16)
                      << std::setw(8) << item.price_rub_t
                      << std::setw(16) << item.cost_rub_t
                      << std::setw(12) << std::setprecision(1) << item.area_2025
                      << std::setprecision(0) << "\n";
        }

        std::cout << "\nЛинейный тренд 2011–2025, урожай = a + b * (год - 2011)\n";
        std::cout << column("Культура", 16) << "     a       b      R2   MAPE%    2026    2027    2028\n";
        for (int crop = 0; crop < N_CROPS; ++crop) {
            const TrendLine line = fit_trend(data.history, crop, 2011, 2025);
            std::cout << column(names[crop], 16)
                      << std::setprecision(3) << std::setw(8) << line.intercept
                      << std::setw(8) << line.slope
                      << std::setw(8) << line.r2
                      << std::setprecision(1) << std::setw(8) << line.mape
                      << std::setprecision(2) << std::setw(8) << trend_at(line, 2026)
                      << std::setw(8) << trend_at(line, 2027)
                      << std::setw(8) << trend_at(line, 2028) << "\n";
        }

        std::cout << "\nМедиана таблицы 10, т/га\n";
        std::cout << column("Культура", 16) << "   2026    2027    2028\n";
        for (int crop = 0; crop < N_CROPS; ++crop) {
            std::cout << column(names[crop], 16) << std::setprecision(2);
            for (int slot = 0; slot < N_YEARS; ++slot) {
                std::cout << std::setw(8) << data.bootstrap[crop][slot].median;
            }
            std::cout << "\n";
        }
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << "\n";
        return 1;
    }
}