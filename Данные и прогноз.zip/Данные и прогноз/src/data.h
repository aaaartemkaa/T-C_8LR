#pragma once
#include "common.h"
#include <filesystem>
#include <stdexcept>
#include <string>
#include <vector>
// Всё, что программа читает с диска, уже разложенное по культурам
//total_area — сумма площадей 2025 года, земельный фонд пяти культур. Он не меняется по годам
struct InputData {
    std::vector<Crop> crops;
    Params params;
    std::vector<YearRow> history;
    Band bootstrap[N_CROPS][N_YEARS]{};
    double total_area = 0;
};

// Ищет yield_area.csv, economics.csv и forecast_bootstrap.csv в каждой папке из roots  и в её подпапке data
InputData load_input(const std::vector<std::filesystem::path>& roots);