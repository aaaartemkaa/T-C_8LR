#include "forecast.h"
#include <cmath>
#include <stdexcept>

TrendLine fit_trend(const std::vector<YearRow>& history, int crop, int year_from, int year_to) {
    double sum_x = 0;
    double sum_y = 0;
    double sum_xx = 0;
    double sum_xy = 0;
    int n = 0;
    for (const YearRow& row : history) {
        if (row.year < year_from || row.year > year_to) {
            continue;
        }
        // 0 оси X — первый год окна, тогда intercept читается как урожайность year_from
        const double x = static_cast<double>(row.year - year_from);
        const double y = row.yield[crop];
        sum_x += x;
        sum_y += y;
        sum_xx += x * x;
        sum_xy += x * y;
        ++n;
    }
    if (n < 3) {
        throw std::runtime_error("Для линейного тренда нужно хотя бы три года");
    }
    const double nd = static_cast<double>(n);
    const double denom = nd * sum_xx - sum_x * sum_x;
    if (std::fabs(denom) < 1e-12) {
        throw std::runtime_error("Не удалось оценить наклон тренда");
    }

    TrendLine line;
    line.n = n;
    line.origin = year_from;
    // Обычные формулы МНК для y = a + b*x, без матриц: точек всего 15
    line.slope = (nd * sum_xy - sum_x * sum_y) / denom;
    line.intercept = (sum_y - line.slope * sum_x) / nd;
    double ss_tot = 0;
    double ss_res = 0;
    double mape_sum = 0;
    int mape_n = 0;
    const double mean_y = sum_y / nd;
    for (const YearRow& row : history) {
        if (row.year < year_from || row.year > year_to) {
            continue;
        }
        const double y = row.yield[crop];
        const double fit = trend_at(line, row.year);
        const double err = y - fit;
        ss_res += err * err;
        const double dev = y - mean_y;
        ss_tot += dev * dev;
        if (std::fabs(y) > 1e-9) {
            mape_sum += std::fabs(err / y);
            ++mape_n;
        }
    }
    // R2 = 1 - (разброс остатков / разброс самого ряда). MAPE — средняя |ошибка| / |факт|, в "%"
    line.r2 = ss_tot < 1e-12 ? 1.0 : 1.0 - ss_res / ss_tot;
    line.mape = mape_n ? 100.0 * mape_sum / static_cast<double>(mape_n) : 0;
    return line;
}

double trend_at(const TrendLine& line, int year) {
    return line.intercept + line.slope * static_cast<double>(year - line.origin);
}